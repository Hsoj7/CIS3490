Name: Joshua Stone
ID: 1013900
Email: jstone04@uoguelph.ca
Date: February 11, 2019
Assign 2

To run my programs, cd into my folder and type make. This will compile each of
the .c files. I chose to make each of the files separate with their own main
functions as it was much easier for testing/debugging programs on their own. To
run each of the programs after compiling, simply type ./[program name] where
[program name] is either P11, P12, P21, P22.
