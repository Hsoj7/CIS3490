#include <stdio.h>

int main(){
  printf("Program compiles and runs :)\n");

  return 0;
}
